from urllib import parse as urlparse


def strip_scheme(url):
    parsed = urlparse.urlparse(url)
    scheme = f"{parsed.scheme}://"
    return parsed.geturl().replace(scheme, '', 1)
