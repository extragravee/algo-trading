import asyncio
import json
import logging
import traceback
from enum import Enum
from json import JSONDecodeError
from urllib import parse as urlparse

from autobahn.asyncio.websocket import WebSocketClientFactory

import fmclient.fmio.net.common.utils as net_utils
import fmclient.fmio.net.common.ws.utils as ws_utils
import fmclient.utils.helper as hlp
from fmclient.fmio.net.common.ws.protocol import register_ws_callback, AgentWebSocketCallbackType, \
    AgentWebSocketClientProtocol
from fmclient.fmio.net.fmapi import FmCommand
from fmclient.fmio.net.fmapi.rest.auth import Auth as FMAuth
from fmclient.utils.constants import LIB_NAME, LIB_VERSION, FM_HOST_FM, FM_HOST_AHM, FM_HOST, FM_HOST_DEFAULT


def _construct_msg(*args):
    return '\n'.join([*args, '\n\0'])


# Message types for incoming and outgoing messages
class OutgoingMessageFrameType(Enum):
    CONNECT = 'CONNECT'
    DISCONNECT = 'DISCONNECT'
    SUBSCRIBE = 'SUBSCRIBE'
    UNSUBSCRIBE = 'UNSUBSCRIBE'
    SEND = 'SEND'


class IncomingMessageFrameType(Enum):
    CONNECTED = 'CONNECTED'
    MESSAGE = 'MESSAGE'
    RECEIPT = 'RECEIPT'
    ERROR = 'ERROR'
    HEARTBEAT = 'HEARTBEAT'


class IncomingMessageType(Enum):
    HOLDING_UPDATE = 'HOLDING-UPDATE'
    ORDERS_UPDATE = 'ORDERS-UPDATE'
    SESSION_UPDATE = 'SESSION-UPDATE'


class BaseWebSocketClient(type):

    def __call__(cls, *args, **kwargs):
        # Do not instantiate this metaclass
        if cls is BaseWebSocketClient:
            raise TypeError(f"{cls.__name__} cannot be instantiated")

        # Pick appropriate subclass
        if cls is WebSocketClient:
            # noinspection PyMethodFirstArgAssignment
            cls = {
                FM_HOST_FM: FmWebSocketClient,
                FM_HOST_AHM: AhmWebSocketClient
            }.get(FM_HOST, FM_HOST_DEFAULT)

        return super(BaseWebSocketClient, cls).__call__(*args, **kwargs)


class WebSocketClient(object, metaclass=BaseWebSocketClient):
    """
    Class to handle websocket communication to FM server
    """

    def __init__(self, name, endpoint, path, marketplace, message_queue: asyncio.Queue, ssl=False) -> None:
        """
        Initialise WS Client connection
        :param endpoint: where to connect
        :param ssl: whether to use SSL for this connection
        """
        super().__init__()
        self._name = name
        self._loop = asyncio.get_event_loop()
        self._address = net_utils.strip_scheme(endpoint).rstrip('/')
        self._path = path
        self._ssl = ssl
        self._mp_id = marketplace
        self._incoming_message_queue = message_queue
        self._stop = False
        self._is_ready = False
        self._is_connected = False
        self._client_protocol = None
        self._sub_ids = []

        self._ws_scheme = u"wss" if ssl else u"ws"
        self._port = 443 if ssl else 80
        self._base_uri = u"{proto}://{addr}:{port}".format(proto=self._ws_scheme, addr=self._address, port=self._port)
        self._ws_endpoint = urlparse.urljoin(self._base_uri, self._path)

        self._setup_logging()

        # Register callbacks
        self.connected = register_ws_callback(AgentWebSocketCallbackType.CONNECT, self)(type(self).connected)
        self.subscribe = register_ws_callback(AgentWebSocketCallbackType.OPEN, self)(type(self).subscribe)
        self.incoming = register_ws_callback(AgentWebSocketCallbackType.MESSAGE, self)(type(self).incoming)
        self.lost_connection = register_ws_callback(AgentWebSocketCallbackType.CLOSE, self)(type(self).lost_connection)

    def _setup_logging(self):
        self._logger = logging.getLogger(".".join(["ws", 'FM', hlp.str_shorten(self._name)]))
        # self._logger.setLevel(logging.DEBUG)  # Dev Only

    def _get_connection_task(self):
        """
        Create the connection task that will connect to the websocket server
        :return:
        """
        try:
            ws_headers = {'Authorization': FMAuth().bearer_auth}
            # protocols = ["v12.stomp", "v11.stomp", "v10.stomp"]
            protocols = []
            factory = WebSocketClientFactory(self._ws_endpoint, headers=ws_headers, protocols=protocols)
            factory.protocol = AgentWebSocketClientProtocol
            factory.setProtocolOptions(maxFramePayloadSize=4 * 1024 * 1024,
                                       maxMessagePayloadSize=4 * 1024 * 1024,
                                       autoPingInterval=30,
                                       autoPingTimeout=5)
            task = self._loop.create_connection(factory, self._address, self._port, ssl=self._ssl)
            return task
        except AssertionError:
            self._logger.error(f"Missing {FM_HOST} Authorisation. Cannot setup connection.")
            raise ConnectionError

    def setup(self):
        try:
            self._logger.debug(f"Connecting to websocket at {self._ws_endpoint}")
            transport, self._client_protocol = self._loop.run_until_complete(self._get_connection_task())
            self._client_protocol.client = self
            # asyncio.run_coroutine_threadsafe(self._process_message_queue(), self._loop)
        except (ConnectionError, OSError):
            self._logger.debug(traceback.format_exc())
            self._logger.error(f"Cannot connect to websocket at `{self._ws_endpoint}`")

    # @register_callback(AgentWebSocketCallbackType.CONNECT, self) # Won't work; self doesn't exist at def time
    def connected(self, response):
        self._logger.info(f"Connected to {FM_HOST} Server {response.peer}")

    # @register_callback(AgentWebSocketCallbackType.OPEN)
    def subscribe(self):  # NOTE: This may vary between servers
        self._client_protocol.send_message(_construct_msg(OutgoingMessageFrameType.CONNECT.name,
                                                          f"authorization:{FMAuth().bearer_auth}",
                                                          f"agent-description:{LIB_NAME} {LIB_VERSION}",
                                                          f"accept-version:1.2,1.1,1.0",
                                                          f"heart-beat:0,30000"))
        self._client_protocol.send_message(_construct_msg(OutgoingMessageFrameType.SUBSCRIBE.name,
                                                          'id:0',
                                                          f"destination:/user/queue/marketplaces/{self._mp_id}"))
        self._client_protocol.send_message(_construct_msg(OutgoingMessageFrameType.SUBSCRIBE.name,
                                                          'id:1',
                                                          f"destination:/topic/marketplaces/{self._mp_id}"))
        self._client_protocol.send_message(_construct_msg(OutgoingMessageFrameType.SUBSCRIBE.name,
                                                          'id:2',
                                                          f"destination:/app/marketplaces/{self._mp_id}"))

        self._sub_ids.extend('0 1 2'.split())

    # @register_callback(AgentWebSocketCallbackType.MESSAGE)
    def incoming(self, message):
        f = ws_utils.parse_frame(message)
        if f:
            msg_type, payload = self.process_frame(f, message)
            if msg_type:
                self._incoming_message_queue.put_nowait({msg_type: payload})

    # @register_callback(AgentWebSocketCallbackType.CLOSE)
    def lost_connection(self, code, reason):
        self._is_ready = False

        async def _re_connect():
            if not self._stop:
                self._logger.debug(f"Reconnecting to the websocket server. Code: {code}; Reason: {reason}")
                while not self._is_ready:
                    try:
                        # self.setup()
                        connection_task = self._loop.create_task(self._get_connection_task())
                        transport, self._client_protocol = await connection_task
                        self._client_protocol.client = self
                        # login_task = self._loop.create_task(self._login())
                        # await login_task
                    except ConnectionError:
                        # give the server two seconds to start accepting connections again
                        await asyncio.sleep(2)
                    else:
                        self._is_ready = True

        asyncio.gather(_re_connect())

    def send_command(self, command: str):
        self._send(f"/app/marketplaces/{self._mp_id}/{hlp.parametrise(command)}")

    def _unsubscribe(self):
        for sub in self._sub_ids:
            self._client_protocol.send_message(_construct_msg(OutgoingMessageFrameType.UNSUBSCRIBE.name,
                                                              f"id:{sub}"))

    def _logout(self):
        self._unsubscribe()
        self._client_protocol.send_message(f"{OutgoingMessageFrameType.DISCONNECT.name}\n\0")  # Note: No blank line

    def _send(self, destination: str, content: str = None):
        msg_frame = [OutgoingMessageFrameType.SEND.name,
                     f"destination:{destination}"]
        if content:
            msg_frame.extend([f"message-type:SESSION",  # NOTE: This shouldn't be hardcoded
                              f"content-length:{len(content)}",
                              "",
                              f"{content}\0"])
        else:
            msg_frame.extend(["", "\0"])

        self._client_protocol.send_message('\n'.join(msg_frame))

    @property
    def stop(self):
        return self._stop

    @stop.setter
    def stop(self, value):
        self._stop = bool(value)
        self._logout()

    def process_frame(self, f, frame_str):
        """
        :param Frame f: Frame object
        :param str frame_str: raw frame content
        """

        def _load_json(json_string):
            json_data = json.loads(f"{{\"original_data\": {json_string}}}")
            try:
                json_data = json.loads(json_string)
            except JSONDecodeError:
                self._logger.error(' '.join(
                    ["Couldn't parse response from server as JSON.",
                     "Perhaps use a custom data parser if expecting response in different format"]
                ))
            finally:
                return json_data

        frame_type, msg_type, payload = f.cmd, None, f.body

        try:
            frame_type = IncomingMessageFrameType[f.cmd.upper()]
            if frame_type == IncomingMessageFrameType.MESSAGE:
                msg_type = IncomingMessageType[hlp.parametrise(f.headers['message-type'])]
                payload = _load_json(f.body)
            if frame_type == IncomingMessageFrameType.HEARTBEAT:
                self._client_protocol.send_message("\n")
                self._logger.debug(f"Wubba Lubba Dub Dub!")

        except KeyError:
            self._logger.warning(f"Unknown response frame type: {f.cmd} (frame length {ws_utils.length(frame_str)})")
            self._logger.error(traceback.format_exc())

        finally:
            self._logger.debug(f"{frame_type}, {msg_type}, {f.headers}, {payload}")
            return msg_type, payload


class AhmWebSocketClient(WebSocketClient):

    def send_command(self, command: FmCommand):
        self._send(f"/app/marketplaces/{self._mp_id}/{hlp.parametrise(command.value)}")


class FmWebSocketClient(WebSocketClient):

    def send_command(self, command: FmCommand):
        state = {'open': 'OPEN', 'pause': 'PAUSED', 'close': 'CLOSED'}[command.value]
        mp = f"/marketplaces/{self._mp_id}"
        content = json.dumps({"state": hlp.parametrise(state), "marketplace": mp})
        self._send(f"/app{mp}", content=content)
