import os

from .utils import helper as hlp
from .utils.constants import FM_HOST_DEFAULT

'''
Following Environment Variables are in place to configure the library:

FM_HOST(str):  
    Defines the FM host to use
    Values: FM | AHM 
    Default: FM
FM_WS_SSL(bool):
    Whether to use SSL to connect to FM WebSockets
    Values: True | False
    Default: True
BOT_WS_DOMAIN(str): 
    Defines the domain to use for WS messages, in case routing these messages to a separate host
    Default: algohost.bmmlab.org
BOT_WS_PORT(int): 
    Port for the above WS domain
    Values: 80(http|ws) | 443(https|wss) | xxxx(non-standard)
    Default: 443(https|wss)
BOT_WS_SSL(bool):
    Whether to use SSL to connect to AlgoHost via WebSockets
    Values: True | False
    Default: True
WS_SIMULATE(bool): 
    Whether to only simulate sending messages over WS
    Values: True | False
    Default: False
'''

# Set host for application
FM_HOST = os.environ.get('FM_HOST', FM_HOST_DEFAULT)
FM_WS_SSL = hlp.str_to_bool(os.environ.get("FM_WS_SSL", "True"))
WS_ADDRESS = os.environ.get("BOT_WS_DOMAIN", "algohost.bmmlab.org")
WS_PORT = int(os.environ.get("BOT_WS_PORT", 443))
WS_SSL = hlp.str_to_bool(os.environ.get("BOT_WS_SSL", "True"))
WS_SIMULATE = hlp.str_to_bool(os.environ.get("BOT_WS_SIMULATE", "False"))
