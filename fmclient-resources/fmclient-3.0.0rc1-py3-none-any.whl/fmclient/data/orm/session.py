"""
A session entity with supporting classes
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum

from fmclient.utils.helper import string_to_local_date


class SessionState(Enum):
    INIT = -1
    OPEN = 0
    PAUSED = 1
    CLOSED = 2


class Session(object):
    """
    A Session entity for Marketplaces

    .. Note:: This class does **not** support :py:func:`copy` and :method:`deepcopy`
        from Python's :py:module:`copy` module.
    """

    fm_id: int
    state: SessionState
    original_id: int
    name: str
    description: str
    date_created: datetime
    date_last_modified: datetime
    date_opened: datetime
    date_closed: datetime

    __instances_by_id = {}
    __fields = {
        'id': ('fm_id', int),
        'state': ('state', lambda x: SessionState[x]),
        'original': ('original_id', int),
        'name': ('name', str),
        'description': ('description', str),
        'createdDate': ('date_created', string_to_local_date),
        'lastModifiedDate': ('date_last_modified', string_to_local_date),
        'openDate': ('date_opened', string_to_local_date),
        'closeDate': ('date_closed', string_to_local_date),
    }
    __enabled_attrs = set([_[0] for _ in __fields.values()])
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    # Add additional attributes
    __enabled_attrs.update('_id _locked'.split())
    _locked = False  # Relevant only for objects but not on class, however, it is required
    __print_fields = 'fm_id state'.split()

    def __new__(cls, id_, options: dict = None) -> Session:
        obj = super().__new__(cls)
        obj._locked = False
        obj._id = id_

        if id_:
            if id_ not in cls.__instances_by_id:
                if options:
                    for option, value in options.items():
                        if option in cls.__fields:
                            attr, type_ = cls.__fields[option]
                            try:
                                obj.__setattr__(attr, type_(value))
                            except (TypeError, KeyError, ValueError, AttributeError):
                                obj.__setattr__(attr, None)

                    obj._locked = True
                    cls.__instances_by_id[id_] = obj
            else:
                # We have this Session with us. Perhaps updated? Likely when OPEN->PAUSE
                # Perform naive update
                obj = cls.__instances_by_id[id_]
                if options:
                    # Unlock the object
                    obj.__dict__['_locked'] = False

                    # Update the values
                    for option, value in options.items():
                        if option in cls.__fields:
                            attr, type_ = cls.__fields[option]
                            try:
                                obj.__setattr__(attr, type_(value))
                            except:
                                pass  # Don't overwrite existing values in case of failure

                    # Lock it back
                    obj._locked = True

        try:
            return cls.__instances_by_id[id_]
        except KeyError:
            raise ValueError(f"Session({id_}) does not exist in this marketplace")

    def __eq__(self, other):
        return self._id == other._id if isinstance(other, Session) else False

    def __hash__(self):
        return hash(self._id)

    def __str__(self):
        return "SID:" + str(self._id) + ":" + str(self.state)

    def __repr__(self) -> str:
        rep = ','.join(
            [':'.join([repr(f), repr(getattr(self, v[0]))]) for f, v in self.__fields.items() if hasattr(self, v[0])]
        )
        return f"Session({self._id}, {{{rep}}})"

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Fetch a remote value here and return it
        if attr not in self.__dict__:
            raise AttributeError(attr)
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)
        if self._locked:
            raise TypeError("'Session' object cannot be modified after creation")

        # Set a remote value here
        self.__dict__[attr] = value

    @property
    def is_open(self) -> bool:
        return self.state is SessionState.OPEN

    @property
    def is_closed(self) -> bool:
        return self.state is SessionState.CLOSED

    @property
    def is_paused(self) -> bool:
        return self.state is SessionState.PAUSED

    @property
    def original(self) -> Session:
        try:
            return self.__class__(self.original_id) if self.original_id else None
        except (AttributeError, ValueError):
            pass

    def is_state(self, state: SessionState) -> bool:
        if not isinstance(state, SessionState):
            return False
        return self.state is state
