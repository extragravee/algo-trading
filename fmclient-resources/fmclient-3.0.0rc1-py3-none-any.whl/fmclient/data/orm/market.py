"""
Market module consisting of Market entity from API and related classes and methods
"""
from __future__ import annotations

import copy
from datetime import datetime
from typing import List, Optional, Dict

from fmclient.utils.helper import string_to_local_date


class Market(object):
    """
    A Market class that represents a market in a marketplace.
    This can be associated with individual Assets in Holdings

    This class only creates an object if doesn't exist already. This ensures reuse and unified storage.

    In order to initialise this object, a dict with following keys need to be passed:
        ['id', 'item', 'name', 'description', 'maximumPrice', 'maximumUnit', 'minimumPrice', 'minimumUnit',
        'priceTick', 'unitTick', 'privateMarket', 'createdDate', 'lastModifiedDate']

    .. Note:: This class does **not** support :py:func:`copy` and :method:`deepcopy`
        from Python's :py:module:`copy` module.
    """

    fm_id: int
    item: str
    name: str
    description: str
    max_price: int
    max_units: int
    min_price: int
    min_units: int
    price_tick: int
    unit_tick: int
    private_market: bool
    private_traders: List[str]
    date_created: datetime
    date_last_modified: datetime
    url_orders_available: str
    url_orders_available_json: str
    url_orders_completed: str
    url_orders_completed_json: str
    url_orders_all: str
    url_private_traders: str

    info_suffixes = ('__initial', '__shorts', '__buy', '__sell')  # TODO: Remove and transfer to Asset? Used by admin

    __instances_by_id = {}
    __instances_by_item = {}
    __fields = {
        'id': ('fm_id', int),
        'item': ('item', str),
        'name': ('name', str),
        'description': ('description', str),
        'maximumPrice': ('max_price', int),
        'maximumUnit': ('max_units', int),
        'minimumPrice': ('min_price', int),
        'minimumUnit': ('min_units', int),
        'priceTick': ('price_tick', int),
        'unitTick': ('unit_tick', int),
        'privateMarket': ('private_market', bool),
        'privateTraders': ('private_traders', list),
        'createdDate': ('date_created', string_to_local_date),
        'lastModifiedDate': ('date_last_modified', string_to_local_date),
    }
    __urls = {
        'ordersAvailable': ('url_orders_available', str),
        'ordersAvailableJson': ('url_orders_available_json', str),
        'ordersCompleted': ('url_orders_completed', str),
        'ordersCompletedJson': ('url_orders_completed_json', str),
        'orders': ('url_orders_all', str),
        'privateTraders': ('url_private_traders', str),  # This should be fetched and stored
    }
    __enabled_attrs = set([_[0] for _ in __fields.values()])
    __enabled_attrs.update([_[0] for _ in __urls.values()])
    __unlocked_fields = {'private_traders'}
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    # Add additional attributes
    __enabled_attrs.update('_id prefix _locked'.split())
    _locked = False  # Relevant only for objects but not on class, however, it is required
    __print_fields = 'fm_id item name private_market'.split()

    def __new__(cls, id_, options: dict = None) -> Market:
        if id_ not in cls.__instances_by_id:
            obj = super().__new__(cls)
            obj._locked = False
            obj._id = id_
            obj.prefix = "/markets/"

            if options:
                for option, value in options.items():
                    if option in cls.__fields:
                        attr, type_ = cls.__fields[option]
                        obj.__setattr__(attr, type_(value))
                    elif option == '_links':
                        for opt_url, url in value.items():
                            if opt_url in cls.__urls:
                                attr, type_ = cls.__urls[opt_url]
                                obj.__setattr__(attr, type_(url['href']))

                obj._locked = True
                cls.__instances_by_id[id_] = obj

                # Special attribute based access to instances
                if hasattr(obj, 'item'):
                    cls.__instances_by_item[obj.item] = obj

        try:
            return cls.__instances_by_id[id_]
        except KeyError:
            raise ValueError(f"Market({id_}) does not exist in this marketplace")

    def update_attr(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)
        if attr not in self.__unlocked_fields:
            raise TypeError(f"'Market' attribute {attr} cannot be set or updated")

        # Remove unlocked attr and set a remote value here
        self.__unlocked_fields.discard(attr)
        self.__dict__[attr] = value

    def __eq__(self, other):
        return self._id == other._id if isinstance(other, Market) else False

    def __hash__(self):
        return hash(self._id)

    def __str__(self) -> str:
        info = ','.join([str(getattr(self, f)) for f in self.__print_fields if hasattr(self, f)])
        return f"Market({info if info else self._id})"

    def __repr__(self) -> str:
        rep = ','.join(
            [':'.join([repr(f), repr(getattr(self, v[0]))]) for f, v in self.__fields.items() if hasattr(self, v[0])]
        )
        return f"Market({self._id}, {{{rep}}})"

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Fetch a remote value here and return it
        if attr not in self.__dict__:
            raise AttributeError(attr)
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)
        if self._locked:
            raise TypeError("'Market' object cannot be modified after creation")

        # Set a remote value here
        self.__dict__[attr] = value

    @classmethod
    def get_by_id(cls, id_) -> Optional[Market]:
        return cls.__instances_by_id.get(id_, None)

    @classmethod
    def get_by_item(cls, item_) -> Optional[Market]:
        return cls.__instances_by_item.get(item_, None)

    @classmethod
    def all(cls) -> Dict[int, Market]:
        return copy.copy(cls.__instances_by_id)


class Asset(object):
    """
    An Asset class that represents current unit holding and grants for a user in a `Market`
    This is usually associated with a `Holding` object.

    In order to initialise this object, a dict with following keys need to be passed:
        ['availableUnits', 'initialShortUnits', 'initialUnits', 'units', 'grants', 'market']

    Here 'grants' is a dict with following keys:
        ['canBuy', 'canSell', 'shortUnits', 'units']

    'market' must be a dict with at least an 'id' field.
    This is an associated object of type `Market`.

    .. Note:: This class does **not** support :py:func:`copy` and :method:`deepcopy`
        from Python's :py:module:`copy` module.
    """

    units: int
    units_available: int
    units_initial: int
    units_initial_short: int
    units_granted: int
    units_granted_short: int
    can_buy: bool
    can_sell: bool
    market: Market

    __fields = {
        'units': ('units', int),
        'availableUnits': ('units_available', int),
        'initialUnits': ('units_initial', int),
        'initialShortUnits': ('units_initial_short', int),
    }
    __grants = {
        'canBuy': ('can_buy', bool),
        'canSell': ('can_sell', bool),
        'shortUnits': ('units_granted_short', int),
        'units': ('units_granted', int),
    }  # This could be a separate object given FM sends an ID for this
    __assoc_obj_lookup_fields = {
        'market': ('market', Market),
    }
    __field_validations = {
        'units': lambda x: False,  # Prevents modification
        'units_available': lambda x: False,  # Prevents modification
        'units_initial': lambda x: isinstance(x, int),
        'units_initial_short': lambda x: x >= 0,
        'units_granted': lambda x: isinstance(x, int),
        'units_granted_short': lambda x: x >= 0,
        'can_buy': lambda x: isinstance(x, bool),
        'can_sell': lambda x: isinstance(x, bool),
        'market': lambda x: False,
    }

    __enabled_attrs = set([_[0] for _ in __fields.values()])
    __enabled_attrs.update([_[0] for _ in __grants.values()])
    __enabled_attrs.update(list(__assoc_obj_lookup_fields))
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    # Add additional attributes
    __enabled_attrs.update('_new'.split())
    _new = True  # Relevant only for objects but not on class, however, it is required
    __print_fields = 'market units units_available units_initial units_initial_short can_buy can_sell'.split()

    def __new__(cls, options: dict = None) -> Asset:
        obj = super().__new__(cls)
        obj._new = True

        if options:
            for option, value in options.items():
                if option in cls.__fields:
                    attr, type_ = cls.__fields[option]
                    obj.__setattr__(attr, type_(value))
                elif option in cls.__assoc_obj_lookup_fields:
                    attr, type_ = cls.__assoc_obj_lookup_fields[option]
                    try:
                        obj.__setattr__(attr, type_(value['id']))
                    except ValueError:
                        obj.__setattr__(attr, type_(value['id'], value))
                elif option == 'grant':
                    for opt_grant, grant_val in value.items():
                        if opt_grant in cls.__grants:
                            attr, type_ = cls.__grants[opt_grant]
                            obj.__setattr__(attr, type_(grant_val))
        obj._new = False

        return obj

    def __str__(self) -> str:
        info = ','.join([str(getattr(self, f)) for f in self.__print_fields if hasattr(self, f)])
        return f"Asset({info if info else None})"

    def __repr__(self) -> str:
        return self.__str__()

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Fetch a remote value here and return it
        if attr not in self.__dict__:
            raise AttributeError(attr)
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Perform any validations
        if not self._new and attr in self.__field_validations:
            validate = self.__field_validations[attr]
            if callable(validate) and not validate(value):
                raise ValueError(f"Cannot set {attr} to {value}")

        # Set a remote value here
        self.__dict__[attr] = value
